# Q3 run log

- Date: 2026-10-15
- Model: gemini-3.6-flash
- Temperature: 0
- Runs: 3
- Zero-shot model: facebook/bart-large-mnli
- Messages: 10 (M01-M05 from the brief, M06-M08 own edge cases, M09-M10 held-out paraphrases)
